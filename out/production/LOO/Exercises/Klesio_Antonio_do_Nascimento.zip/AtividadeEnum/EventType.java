package Exercises.AtividadeEnum;

public enum EventType {
    UI,DATABASE,API
}
