package AA1;

public interface ImpostoMunicipal {
     double calculaIPTU();
}
